// serverCheckers - master server checker game
function serverLaunchGame()
{
  //we are now in a match
  $inMatch = true;
  
  //init the server's boards
  ServerCheckerBoard.init();
  ClientCheckerBoard.init();
  
  //tell the client to start the game
  commandToClient($playerConnection, 'StartGame');
}

function serverBeginGame()
{
}

function ServerCheckerBoard::init(%this)
{
  //init the team counts
  $redCount = 0;
  $blueCount = 0;
  
  //loop through and create the server board
  for(%i=1;%i<65;%i++)
  {
     //check if this is a black checkerboard spot
     if(%this.isBlack(%i))
     {
        //check if this is a checker's starting spot
        if(%i < 24)
        {
           //set the blue team's piece and add to the count
           %this.setPiece(%i, $blue);
           $blueCount++;
        }
        else if(%i > 41)
        {
           //set the red team's piece and add to the count
           %this.setPiece(%i, $red);
           $redCount++;
        }
        else
        {
           //set the blank spot
           %this.setPiece(%i, 0);
        }
     }
     else
     {
        //set the blank spot
        %this.setPiece(%i, 0);
     }
  }
}