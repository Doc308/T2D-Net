// serverCommands - commands for the server to run
function serverCmdGameStarted(%client)
{
  //tell the server to begin the game
  serverBeginGame();
}