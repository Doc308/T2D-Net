// checkerBoard.cs - Set up our checker board and provide game logic for it
function createCheckerBoard(%board)
{
  // Use a composite Sprite to set up an 8x8 grid for our board
  %board.SceneLayer = 30;
  %board.setDefaultSpriteStride( 8, 8 );
  %board.setDefaultSpriteSize( 8, 8 );
  %board.SetBatchLayout( "rect" );
  // Use 3.5 to keep the board centered, so we start & end equal from 0
  for(%y=-3.5;%y<4;%y++)
  {
    for(%x=-3.5;%x<4;%x++)
    {
      %board.addSprite( %x SPC %y );
      
      if((%x + %y) % 2 == 0)
      {
        %board.setSpriteImage("NetCheckers:checker1");
        %board.setSpriteDepth(0); // Depth 0 = White
      }
      else
      {
        %board.setSpriteImage("NetCheckers:checker2");
        %board.setSpriteDepth(1); // Depth 1 = Black
      }
    }
  }
  return %board;
}

function CheckerBoard::isBlack(%this, %pos)
{
   // Check the Depth of the sprite at selected position
   %this.selectSpriteId(%pos);
   if(%this.getSpriteDepth() == 1)
     return true;
   else
     return false;
}

function CheckerBoard::setPiece(%this, %pos, %type)
{
   // Set the board position
   %this.board[%pos] = %type;
}