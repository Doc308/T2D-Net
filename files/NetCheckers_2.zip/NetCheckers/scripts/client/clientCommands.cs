// clientCommands - commands for the client to run
function clientCmdInitClient()
{
   initClient();
}

function clientCmdInMatch()
{
  //spawn the message telling a client they are rejected, we are in a game without you
  MessageBoxOK("Server in a Match...", "The server you are trying to connect to is already in a match.", "");
}

function clientCmdStartGame()
{
  //call the start game on the client side
  clientLaunchGame();
}

function clientCmdSetTeam(%team)
{
  //set the player's team
  $playerTeam = %team;
}