// clientCheckers - local client checkers game
function clientLaunchGame()
{
  //init the client checkerboard
  ClientCheckerBoard.init();

  //call the game started function on the server
  commandToServer('gameStarted');
}

function ClientCheckerBoard::init(%this)
{
  //create container object's for the team
  %this.redPieces = new SimSet();
  %this.bluePieces = new SimSet();
  //loop through and create the checker board and the initial checkers
  for(%i=1;%i<65;%i++)
  {
     //check if the checker board spot is black
     if(%this.isBlack(%i))
     {
        //check to see if we're populating the checker's starting area
        if(%i < 24)
        {
          //create a new blue checker piece
          %piece = %this.initPiece($blue);

          //set the piece to this location
          %this.setClientPiece(%i, $blue, %piece);
        }
        else if(%i > 41)
        {
          //create a new red piece
          %piece = %this.initPiece($red);
          
          //set this piece to this location
          %this.setClientPiece(%i, $red, %piece);
        }
        else
        {
          //set the empty space
          %this.setClientPiece(%i, 0);
        }
     }
     else
     {
        %this.setClientPiece(%i, 0);
     }
  }
}

function ClientCheckerBoard::initPiece(%this, %type)
{
  //check which team the piece is
  if(%type == $red)
  {
    //get the count of current pieces of that color
    %num = %this.redPieces.getCount();
    
    //create a new piece as a clone of our stored piece
    %class = "RedChecker";
    %image = "NetCheckers:sun_neutral";
    %piece = createChecker(%type, %class, %image);
    %piece.setName("redPiece" @ %num);
    
    //add the piece to its color's container object
    %this.redPieces.add(%piece);
  }
  else if(%type == $blue)
  {
    //get the count of current pieces of that color
    %num = %this.bluePieces.getCount();
    
    //create a new piece as a clone of our stored piece
    %class = "BlueChecker";
    %image = "NetCheckers:moon_neutral";
    %piece = createChecker(%type, %class, %image);
    %piece.setName("bluePiece" @ %num);
    
    //add the piece to its color's container object
    %this.bluePieces.add(%piece);
  }
  
  return %piece;
}

function createChecker(%type, %class, %image)
{
   %checker = new Sprite(){
      class = %class;};
   %checker.Size = "6 6";
   %checker.Image = %image;
   %checker.SceneLayer = 20;
   myScene.add(%checker);
   return %checker;
}

function ClientCheckerBoard::setClientPiece(%this, %pos, %type, %piece)
{
  //if the piece isn't empty we do some extra settings
  if(%type != 0)
  {
    //grab the position of the piece
    %this.selectSpriteId(%pos);
    %sPos = %this.getSpriteLocalPosition();
    
    //set the position of the piece
    %piece.setPosition(%sPos);
    //store this Sprite to the board index
    %this.checkerPiece[%pos] = %piece;
  }
  //set the piece's type
  %this.setPiece(%pos, %type);
}

function attemptSelectChecker(%pos)
{
   //first we check if it is our turn
  if(!$myTurn)
  {
     echo("Not your turn");
  }
  else if($clientSelected)
  {
  }
  else
  {
    //grab the selected piece
    %selection = ClientCheckerBoard.getPiece(%pos);
    
    //if it's of the right team then attempt to check it
    if(%selection == $playerTeam)
    {
      //ask the server if we can select it
      commandToServer('attemptSelectChecker', %pos);
    }
    else
    {
      //let the console know this is an invalid selection
      echo("Invalid Selection - Attempt Selection");
    }
  }
}

function clientSelectChecker(%pos)
{
  //set the selection with what's passed in
  $clientSelectedPos = %pos;
  $clientSelected = true;
  
  //have the checker follow the touch device
  ClientCheckerBoard.checkerFollowTouch(%pos);
}

function ClientCheckerBoard::checkerFollowTouch(%this, %pos)
{
  //grab the checker
  %checker = %this.checkerPiece[%pos];
  
  //store the selected checker
  $clientSelectedPiece = %checker;
  
  //set the checker to the $touchObj
  $touchObj = %checker;
}