// serverCheckers - master server checker game
function serverLaunchGame()
{
  //we are now in a match
  $inMatch = true;
  
  //init the server's boards
  ServerCheckerBoard.init();
  ClientCheckerBoard.init();
  
  //tell the client to start the game
  commandToClient($playerConnection, 'StartGame');
}

function serverBeginGame()
{
  //set turn to server's turn
  setTurn($serverConnection);
}

function setTurn(%player)
{
  //get the other player
  %otherPlayer = getOtherPlayer(%player);
  
  //call the client's set turn function properly
  commandToClient(%otherPlayer, 'setPlayerTurn', 0);
  commandToClient(%player, 'setPlayerTurn', 1);
  
  //set the server's turn properly
  $playersTurn = %player;
}

function getOtherPlayer(%player)
{
  //check to see what play was passed and return the other player
  if(%player == $playerConnection)
  {
    %otherPlayer = $serverConnection;
  }
  else
  {
    %otherPlayer = $playerConnection;
  }
  
  return %otherPlayer;
}

function ServerCheckerBoard::init(%this)
{
  //init the team counts
  $redCount = 0;
  $blueCount = 0;
  
  //loop through and create the server board
  for(%i=1;%i<65;%i++)
  {
     //check if this is a black checkerboard spot
     if(%this.isBlack(%i))
     {
        //check if this is a checker's starting spot
        if(%i < 24)
        {
           //set the blue team's piece and add to the count
           %this.setPiece(%i, $blue);
           $blueCount++;
        }
        else if(%i > 41)
        {
           //set the red team's piece and add to the count
           %this.setPiece(%i, $red);
           $redCount++;
        }
        else
        {
           //set the blank spot
           %this.setPiece(%i, 0);
        }
     }
     else
     {
        //set the blank spot
        %this.setPiece(%i, 0);
     }
  }
}

function serverAttemptSelectChecker(%client, %pos)
{
  //check if it's this client's turn
  if($playersTurn != %client)
  {
    //it is not this client's turn, nice try
    commandToClient(%client, 'notYourTurn');
  }
  else if($playersTurn == %client)
  {
    //grab the selection
    %selection = ServerCheckerBoard.getPiece(%pos);
    
    //check if this is the client's piece, or a king
    if(%selection == %client.team)
    {
      //proper move, process sit
      serverSelectChecker(%client, %pos);
    }
    else
    {
      //the client cannot move another team's piece
      commandToClient(%client, 'selectCheckerResponse', %pos, 0);
    }
  }
}

function serverSelectChecker(%client, %pos)
{
  //set the selected piece
  $playersTurn.selectedPos = %pos;
  $playersTurn.hasSelected = true;
  
  //respond to the client
  commandToClient(%client, 'selectCheckerResponse', %pos, 1);
}