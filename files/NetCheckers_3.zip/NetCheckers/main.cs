function NetCheckers::create( %this )
{
   // Checkers
   $red = 1;
   $blue = 2;
   $redKing = 3;
   $blueKing = 4;
   exec("./scripts/execs.cs");
}


function NetCheckers::destroy( %this )
{
}