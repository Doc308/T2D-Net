// serverCheckers - master server checker game
function serverLaunchGame()
{
  //we are now in a match
  $inMatch = true;
  
  //tell the client to start the game
  commandToClient($playerConnection, 'StartGame');
}

function serverBeginGame()
{
}