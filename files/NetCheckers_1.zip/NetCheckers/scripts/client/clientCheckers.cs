// clientCheckers - local client checkers game
function clientLaunchGame()
{
    //call the game started function on the server
  commandToServer('gameStarted');
}